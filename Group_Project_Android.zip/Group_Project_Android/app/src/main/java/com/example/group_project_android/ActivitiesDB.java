package com.example.group_project_android;

import java.util.ArrayList;

public class ActivitiesDB {

    private static ActivitiesDB instance = null;

    public static ActivitiesDB getInstance() {
        if (instance == null) {
            instance = new ActivitiesDB();
        }
        return instance;
    }
    private ActivitiesDB(){
        this.activityList = new ArrayList<ActivityDetails>();

        activityList.add(new ActivityDetails(1,"Sunset Cance Tour of the Waterfront","ashdhjqi md -biu m",2,"Sigma",52,"ic_person",929829));
        activityList.add(new ActivityDetails(2,"Sunset Cance Tour of the Waterfront","ashdhjqi md -biu m",2,"Sigma",52,"ic_person",1221244));
        activityList.add(new ActivityDetails(3,"Sunset Cance Tour of the Waterfront","ashdhjqi md -biu m",2,"Sigma",52,"ic_person",12211445));
    }
    private ArrayList<ActivityDetails> activityList;
    ArrayList<UserAct> favlist= new ArrayList<>();
//    ArrayList<UserAct> booklist= new ArrayList<>();

    public ArrayList<UserAct> getFavlist() {
        return favlist;
    }
//
//    public ArrayList<UserAct> getBooklist() {
//        return booklist;
//    }

    public ArrayList<ActivityDetails> getActivityList(){
        return this.activityList;
    }
}
