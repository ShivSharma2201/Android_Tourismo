package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

public class FavAct extends AppCompatActivity {
    ArrayList<UserAct> favdDetailss;
    ListView listViewf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav);
        ArrayList<String> activityName = new ArrayList<>();
        ArrayList<Float> price= new ArrayList<>();
        ArrayList<String> imageName = new ArrayList<>();

        Intent currentIntent = this.getIntent();
        UserDetails ucf = (UserDetails) currentIntent.getSerializableExtra("USER_DETAILS");
        favdDetailss= ActivitiesDB.getInstance().getFavlist();

        for(int i=0;i<favdDetailss.size();i++){
            if(favdDetailss.get(i).us.getId()==ucf.getId()){
            activityName.add(favdDetailss.get(i).act.getNameOfActivity());
            price.add(favdDetailss.get(i).act.getPrice());
            imageName.add(favdDetailss.get(i).act.getImageName());}
        }
        MyListAdapter adapter = new MyListAdapter(this,activityName,imageName,price);
        listViewf =(ListView) findViewById(R.id.list);
        listViewf.setAdapter(adapter);

        listViewf.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(FavAct.this, "Avtivity "+favdDetailss.get(i).act.getNameOfActivity()+" removed from favourites!", Toast.LENGTH_SHORT).show();
                favdDetailss.remove(i);
                finish();
                startActivity(getIntent());
            }
        });
        listViewf.invalidateViews();

    }
}