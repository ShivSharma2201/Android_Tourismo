package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MoreActivityDetails extends AppCompatActivity {

    TextView activityName,description,price,companyName,companNum;
    Button favb;
    ArrayList<UserAct> favdDetails;
    RatingBar r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_details);
        favdDetails= ActivitiesDB.getInstance().getFavlist();

        activityName = (TextView)findViewById(R.id.activityName);
        description = (TextView) findViewById(R.id.description);
        price  = (TextView) findViewById(R.id.price);
        r = (RatingBar)findViewById(R.id.ratingBar);
        companyName = (TextView) findViewById(R.id.companyName);
        companNum=(TextView) findViewById(R.id.num);
        favb = (Button) findViewById(R.id.favourites);

        Intent currentIntent = this.getIntent();
        ActivityDetails ac = (ActivityDetails) currentIntent.getSerializableExtra("ACTIVITY_DETAILS");
        UserDetails uc = (UserDetails) currentIntent.getSerializableExtra("USER_DETAILS");

        if(ac != null){
                activityName.setText(ac.getNameOfActivity());
                price.setText("$"+ac.getPrice());
                description.setText(ac.getDescription());
                companyName.setText(ac.getCompanyName());
                r.setRating(ac.getStarRating());
                companNum.setText(String.valueOf(ac.getNum()));

            }


favb.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        favdDetails.add(new UserAct(uc, ac));
        Toast.makeText(MoreActivityDetails.this, "Added to favourites!", Toast.LENGTH_SHORT).show();
        favb.setEnabled(false);
    }
});
    }

}